---
name: devops-expert
description: Expert DevOps engineer specializing in CI/CD, containerization (Docker), Kubernetes, AWS, and Azure. Use when you need infrastructure-as-code (Terraform), pipeline automation, or platform engineering expertise.
---

# Expert DevOps Engineer

You are an expert DevOps engineer who designs and implements reliable, scalable, and secure infrastructure and deployment pipelines. You specialize in automation, infrastructure-as-code (IaC), and platform engineering across AWS and Azure environments.

## Core Capabilities

- **Infrastructure as Code**: Expertise in Terraform and CloudFormation/Bicep.
- **CI/CD Pipeline Automation**: Implementing robust pipelines using GitHub Actions, GitLab CI, and Jenkins.
- **Containerization & Orchestration**: Deep knowledge of Docker, Kubernetes (EKS/AKS), and service mesh (Istio/Linkerd).
- **Cloud Infrastructure**: Architecting and managing environments in AWS and Azure.
- **Observability & Reliability**: Setting up Prometheus, Grafana, and ELK/Loki for monitoring and logging.

## Workflow Patterns

When tasked with a DevOps project, follow this structured workflow:

1.  **Requirement Analysis**: Assess the application architecture, scalability needs, and security requirements.
2.  **Platform Selection**: Choose appropriate cloud services (AWS vs. Azure) and tools based on project constraints.
3.  **Infrastructure Design**: Draft IaC templates (Terraform/Bicep) for networking, compute, and storage.
4.  **Pipeline Construction**: Design and implement CI/CD stages (Lint, Test, Build, Scan, Deploy).
5.  **Security & Observability**: Integrate secret management (Vault), IAM/RBAC, and monitoring.

## Domain Specific Knowledge

Refer to these guides for expert patterns and best practices:

- **AWS Architecture**: [references/aws.md](references/aws.md)
- **Azure Architecture**: [references/azure.md](references/azure.md)
- **Advanced Azure Terraform**: [references/azure-terraform-advanced.md](references/azure-terraform-advanced.md)
- **Kubernetes Patterns**: [references/k8s.md](references/k8s.md)
- **CI/CD Best Practices**: [references/cicd.md](references/cicd.md)
- **Containerization Patterns**: [references/containers.md](references/containers.md)

## Guiding Principles

- **Automation First**: Eliminate manual processes and ensure all changes are version-controlled.
- **Security by Design**: Implement the principle of least privilege and embed security scanning in all pipelines.
- **Reproducibility**: Infrastructure must be reproducible through IaC across different environments (Dev, Staging, Prod).
- **Cost Efficiency**: Optimize resource utilization and use cost-effective cloud services.
- **Scalability**: Design systems to handle load variations automatically.
\n\n# Reference: AWS Infrastructure Expert Patterns\n
# AWS Infrastructure Expert Patterns

## VPC Architecture
- **Multi-AZ Setup**: Minimum 2 AZs, preferably 3.
- **Subnet Separation**:
  - **Public Subnets**: NAT Gateways, ALBs.
  - **Private Subnets**: Application instances, EKS nodes.
  - **Database Subnets**: Isolated, no internet access.

## EKS (Elastic Kubernetes Service)
### Terraform Pattern
```hcl
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 20.0"

  cluster_name    = "my-cluster"
  cluster_version = "1.29"

  vpc_id     = module.vpc.vpc_id
  subnet_ids = module.vpc.private_subnets

  eks_managed_node_groups = {
    standard = {
      instance_types = ["t3.medium"]
      min_size     = 3
      max_size     = 10
      desired_size = 3
    }
  }
}
```

## IAM & Security
- **IAM Roles for Service Accounts (IRSA)**: Assign IAM roles to specific K8s pods.
- **Principle of Least Privilege**: Use narrow scopes for IAM policies.
- **KMS**: Encrypt data at rest (S3, EBS, RDS).

## Storage
- **S3**: Lifecycle policies for cost optimization.
- **EBS**: Use GP3 for better price/performance.

## Content Delivery
- **CloudFront**: Distribution with OAC (Origin Access Control) for S3.
- **ACM**: SSL/TLS certificate management.
\n\n# Reference: Azure Infrastructure Expert Patterns\n
# Azure Infrastructure Expert Patterns

## VNet Architecture
- **VNet Peering**: Hub-and-Spoke topology for enterprise networking.
- **Service Endpoints/Private Links**: Secure database/storage access.
- **NSG (Network Security Groups)**: Inbound/outbound traffic control.

## AKS (Azure Kubernetes Service)
### Terraform Pattern
```hcl
resource "azurerm_kubernetes_cluster" "aks" {
  name                = "my-aks-cluster"
  location            = azurerm_resource_group.rg.location
  resource_group_name = azurerm_resource_group.rg.name
  dns_prefix          = "myaks"

  default_node_pool {
    name       = "default"
    node_count = 3
    vm_size    = "Standard_DS2_v2"
    vnet_subnet_id = azurerm_subnet.aks_subnet.id
  }

  identity {
    type = "SystemAssigned"
  }

  network_profile {
    network_plugin = "azure"
    load_balancer_sku = "standard"
  }
}
```

## Identity & Access (RBAC)
- **Managed Identity**: Use System or User assigned identities for pod-to-azure auth.
- **Azure AD Integration**: K8s RBAC integration with Azure Entra ID.

## Storage & Database
- **Azure Files/Disks**: CSI driver integration for AKS.
- **Azure Key Vault**: Secret management with Azure Key Vault Provider for Secrets Store CSI Driver.

## Management & Governance
- **Azure Monitor/Log Analytics**: Container insights for AKS.
- **Azure Policy**: Enforce cluster compliance (e.g., must use specific images).
\n\n# Reference: Advanced Azure Terraform Patterns\n
# Advanced Azure Terraform Patterns

## Azure Verified Modules (AVM)
- **Standardization**: Always prefer [Azure Verified Modules](https://azure.github.io/Azure-Verified-Modules/) for consistency, security, and best practices.
- **Resource Naming**: AVM handles resource naming conventions automatically based on Azure CAF (Cloud Adoption Framework).
- **Telemetry**: Be aware that AVM often includes telemetry; disable if organizational policy requires it (`enable_telemetry = false`).

## Module Layering & Orchestration
### The 3-Layer Approach
1.  **Foundational Layer**: Global resources (VNets, Hub-Spoke Peering, Log Analytics, Key Vaults).
2.  **Platform/Shared Layer**: Common services used by multiple apps (AKS Clusters, Shared Databases, ACR).
3.  **Application Layer**: App-specific resources (App Service, CosmosDB, Function Apps).

## Nested Modules & Composition
- **Composition over Inheritance**: Use "Wrapper Modules" to bundle AVMs together rather than deeply nesting custom logic.
- **Dependency Management**: Use `depends_on` between modules only when implicit dependencies (outputs/inputs) are insufficient.

## Complex State Management
### Remote State & Workspaces
- **Backend**: Use `azurerm` backend with a dedicated Storage Account and Blob Container.
- **State Locking**: Ensure Lease-based locking is active on the blob.
- **Data Sharing**: Use `terraform_remote_state` data sources to pull foundational outputs (like `vnet_id`) into higher layers.

### State Splitting for Blast Radius
- Split state files by **Environment** (Dev/Prod) AND **Layer** (Network/Identity/Compute).
- **Pro Tip**: Use a "Terragrunt" or "Terraform Stacks" approach for orchestrating multiple state files across environments.

## Example: Layered VNet with AVM
```hcl
module "avm_vnet" {
  source  = "Azure/avm-res-network-virtualnetwork/azurerm"
  version = "0.1.0"

  name                = "vnet-prod-uswest"
  resource_group_name = azurerm_resource_group.rg.name
  location            = "westus"
  address_space       = ["10.0.0.0/16"]

  subnets = {
    aks_subnet = {
      address_prefixes = ["10.0.1.0/24"]
    }
    db_subnet = {
      address_prefixes = ["10.0.2.0/24"]
      delegations = {
        postgres = "Microsoft.DBforPostgreSQL/flexibleServers"
      }
    }
  }
}
```
\n\n# Reference: CI/CD Expert Patterns\n
# CI/CD Expert Patterns

## GitHub Actions
### Reusable Workflow for Security & Build
```yaml
name: Security and Build
on:
  workflow_call:
    inputs:
      environment:
        required: true
        type: string
jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run Trivy vulnerability scanner
        uses: aquasecurity/trivy-action@master
        with:
          image-ref: 'your-app:${{ github.sha }}'
          format: 'table'
          exit-code: '1'
          ignore-unfixed: true
          vuln-type: 'os,library'
          severity: 'CRITICAL,HIGH'
```

## GitLab CI
### Multi-Project Pipeline Pattern
```yaml
stages:
  - test
  - deploy

deploy_to_prod:
  stage: deploy
  trigger:
    project: infrastructure/prod-deploy
    branch: main
  rules:
    - if: $CI_COMMIT_BRANCH == "main"
```

## GitOps (ArgoCD)
### Application Set Pattern
```yaml
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: guestbook
spec:
  generators:
  - list:
      elements:
      - cluster: engineering-dev
        url: https://1.2.3.4
      - cluster: engineering-prod
        url: https://2.4.6.8
  template:
    metadata:
      name: '{{cluster}}-guestbook'
    spec:
      project: default
      source:
        repoURL: https://github.com/argoproj/argocd-example-apps.git
        targetRevision: HEAD
        path: guestbook
      destination:
        server: '{{url}}'
        namespace: guestbook
```

## Deployment Strategies
- **Canary**: Deploy to 5-10% of users first.
- **Blue-Green**: Switch entire traffic to new version.
- **Rolling**: Update instances one by one.
- **Shadow**: Mirror traffic to new version without affecting users.
\n\n# Reference: Kubernetes Expert Patterns\n
# Kubernetes Expert Patterns

## Standard Deployment with HPA
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-server
  labels:
    app: api-server
spec:
  replicas: 3
  selector:
    matchLabels:
      app: api-server
  template:
    metadata:
      labels:
        app: api-server
    spec:
      containers:
      - name: api
        image: api:v1.2.3
        resources:
          requests:
            cpu: 100m
            memory: 256Mi
          limits:
            cpu: 500m
            memory: 512Mi
        ports:
        - containerPort: 8080
        livenessProbe:
          httpGet:
            path: /healthz
            port: 8080
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: api-server-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: api-server
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

## Ingress with NGINX
```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: api-ingress
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  tls:
  - hosts:
    - api.example.com
    secretName: api-tls
  rules:
  - host: api.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: api-server
            port:
              number: 80
```

## ConfigMap & Secret Management
### Sealed Secrets or Vault
- **Best Practice**: Never commit raw Secrets.
- Use **Sealed Secrets** for GitOps-friendly encrypted secrets.
- Use **HashiCorp Vault** for enterprise secret management.

## Observability
### Prometheus/Grafana (kube-prometheus-stack)
- **ServiceMonitor**: Custom resource to define scraping targets.
- **AlertManager**: Routing alerts to Slack/PagerDuty.

## Security (NetworkPolicies)
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: api-allow-db
spec:
  podSelector:
    matchLabels:
      app: api-server
  policyTypes:
  - Egress
  egress:
  - to:
    - podSelector:
        matchLabels:
          app: database
    ports:
    - protocol: TCP
      port: 5432
```
\n\n# Reference: Containerization Expert Patterns\n
# Containerization Expert Patterns

## Dockerfile Best Practices
### Secure, Multi-Stage Build
```dockerfile
# Build Stage
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

# Final Stage (Runner)
FROM node:20-alpine
WORKDIR /app
# Use non-root user for security
RUN addgroup -S appgroup && adduser -S appuser -G appgroup
USER appuser
# Copy only necessary artifacts
COPY --from=build /app/dist ./dist
COPY --from=build /app/node_modules ./node_modules
# Define healthy timeout/grace
EXPOSE 3000
CMD ["node", "dist/main.js"]
```

## Security Best Practices
- **Base Images**: Prefer minimal images (e.g., Alpine, Distroless).
- **Scanning**: Regularly scan images (e.g., Trivy, Grype, Docker Scout).
- **Non-Root**: Never run as root (UID 0) in production.
- **Read-Only**: Use read-only root filesystems where possible (`readOnlyRootFilesystem: true` in K8s).

## Image Management
- **Tagging**: Use semantic versioning or commit SHA. Avoid `latest`.
- **Registry**: Use private registries (ECR, ACR, GCR).
- **Caching**: Order `COPY` and `RUN` commands to maximize layer caching.

## Runtime Security
- **Resource Limits**: CPU/Memory requests and limits.
- **Secrets**: Do not bake secrets into images. Inject at runtime.
- **Signals**: Ensure app handles SIGTERM for graceful shutdown.
