# AWS Infrastructure Expert Patterns

## VPC Architecture
- **Multi-AZ Setup**: Minimum 2 AZs, preferably 3.
- **Subnet Separation**:
  - **Public Subnets**: NAT Gateways, ALBs.
  - **Private Subnets**: Application instances, EKS nodes.
  - **Database Subnets**: Isolated, no internet access.

## EKS (Elastic Kubernetes Service)
### Terraform Pattern
```hcl
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 20.0"

  cluster_name    = "my-cluster"
  cluster_version = "1.29"

  vpc_id     = module.vpc.vpc_id
  subnet_ids = module.vpc.private_subnets

  eks_managed_node_groups = {
    standard = {
      instance_types = ["t3.medium"]
      min_size     = 3
      max_size     = 10
      desired_size = 3
    }
  }
}
```

## IAM & Security
- **IAM Roles for Service Accounts (IRSA)**: Assign IAM roles to specific K8s pods.
- **Principle of Least Privilege**: Use narrow scopes for IAM policies.
- **KMS**: Encrypt data at rest (S3, EBS, RDS).

## Storage
- **S3**: Lifecycle policies for cost optimization.
- **EBS**: Use GP3 for better price/performance.

## Content Delivery
- **CloudFront**: Distribution with OAC (Origin Access Control) for S3.
- **ACM**: SSL/TLS certificate management.
