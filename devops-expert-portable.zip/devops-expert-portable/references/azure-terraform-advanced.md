# Advanced Azure Terraform Patterns

## Azure Verified Modules (AVM)
- **Standardization**: Always prefer [Azure Verified Modules](https://azure.github.io/Azure-Verified-Modules/) for consistency, security, and best practices.
- **Resource Naming**: AVM handles resource naming conventions automatically based on Azure CAF (Cloud Adoption Framework).
- **Telemetry**: Be aware that AVM often includes telemetry; disable if organizational policy requires it (`enable_telemetry = false`).

## Module Layering & Orchestration
### The 3-Layer Approach
1.  **Foundational Layer**: Global resources (VNets, Hub-Spoke Peering, Log Analytics, Key Vaults).
2.  **Platform/Shared Layer**: Common services used by multiple apps (AKS Clusters, Shared Databases, ACR).
3.  **Application Layer**: App-specific resources (App Service, CosmosDB, Function Apps).

## Nested Modules & Composition
- **Composition over Inheritance**: Use "Wrapper Modules" to bundle AVMs together rather than deeply nesting custom logic.
- **Dependency Management**: Use `depends_on` between modules only when implicit dependencies (outputs/inputs) are insufficient.

## Complex State Management
### Remote State & Workspaces
- **Backend**: Use `azurerm` backend with a dedicated Storage Account and Blob Container.
- **State Locking**: Ensure Lease-based locking is active on the blob.
- **Data Sharing**: Use `terraform_remote_state` data sources to pull foundational outputs (like `vnet_id`) into higher layers.

### State Splitting for Blast Radius
- Split state files by **Environment** (Dev/Prod) AND **Layer** (Network/Identity/Compute).
- **Pro Tip**: Use a "Terragrunt" or "Terraform Stacks" approach for orchestrating multiple state files across environments.

## Example: Layered VNet with AVM
```hcl
module "avm_vnet" {
  source  = "Azure/avm-res-network-virtualnetwork/azurerm"
  version = "0.1.0"

  name                = "vnet-prod-uswest"
  resource_group_name = azurerm_resource_group.rg.name
  location            = "westus"
  address_space       = ["10.0.0.0/16"]

  subnets = {
    aks_subnet = {
      address_prefixes = ["10.0.1.0/24"]
    }
    db_subnet = {
      address_prefixes = ["10.0.2.0/24"]
      delegations = {
        postgres = "Microsoft.DBforPostgreSQL/flexibleServers"
      }
    }
  }
}
```
