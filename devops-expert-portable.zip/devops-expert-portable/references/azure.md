# Azure Infrastructure Expert Patterns

## VNet Architecture
- **VNet Peering**: Hub-and-Spoke topology for enterprise networking.
- **Service Endpoints/Private Links**: Secure database/storage access.
- **NSG (Network Security Groups)**: Inbound/outbound traffic control.

## AKS (Azure Kubernetes Service)
### Terraform Pattern
```hcl
resource "azurerm_kubernetes_cluster" "aks" {
  name                = "my-aks-cluster"
  location            = azurerm_resource_group.rg.location
  resource_group_name = azurerm_resource_group.rg.name
  dns_prefix          = "myaks"

  default_node_pool {
    name       = "default"
    node_count = 3
    vm_size    = "Standard_DS2_v2"
    vnet_subnet_id = azurerm_subnet.aks_subnet.id
  }

  identity {
    type = "SystemAssigned"
  }

  network_profile {
    network_plugin = "azure"
    load_balancer_sku = "standard"
  }
}
```

## Identity & Access (RBAC)
- **Managed Identity**: Use System or User assigned identities for pod-to-azure auth.
- **Azure AD Integration**: K8s RBAC integration with Azure Entra ID.

## Storage & Database
- **Azure Files/Disks**: CSI driver integration for AKS.
- **Azure Key Vault**: Secret management with Azure Key Vault Provider for Secrets Store CSI Driver.

## Management & Governance
- **Azure Monitor/Log Analytics**: Container insights for AKS.
- **Azure Policy**: Enforce cluster compliance (e.g., must use specific images).
