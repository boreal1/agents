# CI/CD Expert Patterns

## GitHub Actions
### Reusable Workflow for Security & Build
```yaml
name: Security and Build
on:
  workflow_call:
    inputs:
      environment:
        required: true
        type: string
jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run Trivy vulnerability scanner
        uses: aquasecurity/trivy-action@master
        with:
          image-ref: 'your-app:${{ github.sha }}'
          format: 'table'
          exit-code: '1'
          ignore-unfixed: true
          vuln-type: 'os,library'
          severity: 'CRITICAL,HIGH'
```

## GitLab CI
### Multi-Project Pipeline Pattern
```yaml
stages:
  - test
  - deploy

deploy_to_prod:
  stage: deploy
  trigger:
    project: infrastructure/prod-deploy
    branch: main
  rules:
    - if: $CI_COMMIT_BRANCH == "main"
```

## GitOps (ArgoCD)
### Application Set Pattern
```yaml
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: guestbook
spec:
  generators:
  - list:
      elements:
      - cluster: engineering-dev
        url: https://1.2.3.4
      - cluster: engineering-prod
        url: https://2.4.6.8
  template:
    metadata:
      name: '{{cluster}}-guestbook'
    spec:
      project: default
      source:
        repoURL: https://github.com/argoproj/argocd-example-apps.git
        targetRevision: HEAD
        path: guestbook
      destination:
        server: '{{url}}'
        namespace: guestbook
```

## Deployment Strategies
- **Canary**: Deploy to 5-10% of users first.
- **Blue-Green**: Switch entire traffic to new version.
- **Rolling**: Update instances one by one.
- **Shadow**: Mirror traffic to new version without affecting users.
