# Containerization Expert Patterns

## Dockerfile Best Practices
### Secure, Multi-Stage Build
```dockerfile
# Build Stage
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

# Final Stage (Runner)
FROM node:20-alpine
WORKDIR /app
# Use non-root user for security
RUN addgroup -S appgroup && adduser -S appuser -G appgroup
USER appuser
# Copy only necessary artifacts
COPY --from=build /app/dist ./dist
COPY --from=build /app/node_modules ./node_modules
# Define healthy timeout/grace
EXPOSE 3000
CMD ["node", "dist/main.js"]
```

## Security Best Practices
- **Base Images**: Prefer minimal images (e.g., Alpine, Distroless).
- **Scanning**: Regularly scan images (e.g., Trivy, Grype, Docker Scout).
- **Non-Root**: Never run as root (UID 0) in production.
- **Read-Only**: Use read-only root filesystems where possible (`readOnlyRootFilesystem: true` in K8s).

## Image Management
- **Tagging**: Use semantic versioning or commit SHA. Avoid `latest`.
- **Registry**: Use private registries (ECR, ACR, GCR).
- **Caching**: Order `COPY` and `RUN` commands to maximize layer caching.

## Runtime Security
- **Resource Limits**: CPU/Memory requests and limits.
- **Secrets**: Do not bake secrets into images. Inject at runtime.
- **Signals**: Ensure app handles SIGTERM for graceful shutdown.
